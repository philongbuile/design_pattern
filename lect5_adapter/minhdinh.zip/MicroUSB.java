package adapter;

public interface MicroUSB {
    public void useMicroUSB();
    public void recharge();
}
