package adapter;

public class iPhone implements Lightning{
    public void useLightning()
    {
        System.out.println("I am using lightning");
    }
    public void recharge()
    {
        System.out.println("I am recharging");
    }
}
