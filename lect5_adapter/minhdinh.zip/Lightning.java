package adapter;

public interface Lightning {
    public void useLightning();
    public void recharge();
}
