package adapter;

public class Android implements MicroUSB{
    public void useMicroUSB()
    {
        System.out.println("I am suing Micro usb");
    }
    public void recharge()
    {
        System.out.println("I am recharging");
    }
}
